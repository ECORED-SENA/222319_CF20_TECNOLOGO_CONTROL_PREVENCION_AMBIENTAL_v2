function ExecuteScript(strId)
{
  switch (strId)
  {
      case "6nPHxJ3S2qT":
        Script1();
        break;
  }
}

function Script1()
{
  window.close();
}

